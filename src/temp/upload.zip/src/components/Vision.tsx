import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

export default function Vision() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="vision" className="relative py-28 sm:py-40 overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-1/2 right-0 w-[500px] h-[500px] rounded-full bg-jarvis-blue/[0.025] blur-[180px] pointer-events-none -translate-y-1/2" />

      <div ref={ref} className="max-w-3xl mx-auto px-6 lg:px-10">
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="text-[11px] tracking-[0.5em] uppercase text-jarvis-cyan/60 mb-10"
        >
          The Vision
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 35 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
          className="font-display font-bold text-2xl sm:text-3xl md:text-[2.75rem] text-white leading-[1.2] tracking-wide"
        >
          Building a humanoid robot{' '}
          <span className="bg-gradient-to-r from-jarvis-cyan via-jarvis-blue to-jarvis-cyan bg-clip-text text-transparent">
            from the ground up.
          </span>
        </motion.h2>

        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="mt-10 space-y-5"
        >
          <p className="text-jarvis-muted text-[15px] sm:text-base leading-[1.8]">
            Project JARVIS is an initiative to design, build, and program a
            4-foot humanoid robot using accessible hardware — Raspberry Pi as
            the central brain and Arduino boards for real-time hardware control.
          </p>
          <p className="text-jarvis-muted text-[15px] sm:text-base leading-[1.8]">
            The goal is to create a functional bipedal robot that integrates
            mechanical design, electronics, and embedded computing into a
            cohesive system — demonstrating that advanced robotics can be
            approached with determination and open-source tools.
          </p>
        </motion.div>

        {/* Decorative divider */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={inView ? { scaleX: 1 } : {}}
          transition={{ duration: 1.5, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="mt-20 h-[1px] w-full bg-gradient-to-r from-jarvis-cyan/20 via-jarvis-border/30 to-transparent origin-left"
        />
      </div>
    </section>
  );
}
