import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const components = [
  {
    name: 'Raspberry Pi',
    role: 'Main Brain',
    desc: 'Central processing unit handling high-level logic, decision making, and communication.',
    accent: 'cyan' as const,
  },
  {
    name: 'Arduino Boards',
    role: 'Hardware Control',
    desc: 'Real-time motor control, sensor reading, and actuator management.',
    accent: 'blue' as const,
  },
  {
    name: 'Raspberry Pi Pico',
    role: 'Microcontroller',
    desc: 'Lightweight embedded processing for dedicated subsystem tasks.',
    accent: 'purple' as const,
  },
  {
    name: 'Edge Computing',
    role: 'Architecture',
    desc: 'Distributed processing across multiple boards for efficient real-time operation.',
    accent: 'white' as const,
  },
];

const accentStyles = {
  cyan: {
    dot: 'bg-jarvis-cyan',
    border: 'border-jarvis-cyan/20',
    hoverBorder: 'hover:border-jarvis-cyan/35',
    glow: 'group-hover:shadow-[0_0_30px_rgba(0,229,255,0.06)]',
  },
  blue: {
    dot: 'bg-jarvis-blue',
    border: 'border-jarvis-blue/20',
    hoverBorder: 'hover:border-jarvis-blue/35',
    glow: 'group-hover:shadow-[0_0_30px_rgba(61,90,254,0.06)]',
  },
  purple: {
    dot: 'bg-jarvis-purple',
    border: 'border-jarvis-purple/20',
    hoverBorder: 'hover:border-jarvis-purple/35',
    glow: 'group-hover:shadow-[0_0_30px_rgba(124,77,255,0.06)]',
  },
  white: {
    dot: 'bg-white/60',
    border: 'border-white/10',
    hoverBorder: 'hover:border-white/20',
    glow: 'group-hover:shadow-[0_0_30px_rgba(255,255,255,0.03)]',
  },
};

export default function Architecture() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section id="architecture" className="relative py-28 sm:py-40 overflow-hidden">
      <div className="absolute top-0 left-0 w-[600px] h-[600px] rounded-full bg-jarvis-blue/[0.02] blur-[200px] pointer-events-none" />

      <div ref={ref} className="max-w-5xl mx-auto px-6 lg:px-10">
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-[11px] tracking-[0.5em] uppercase text-jarvis-cyan/60 mb-5"
        >
          System Design
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 35 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.12 }}
          className="font-display font-bold text-2xl sm:text-3xl md:text-[2.75rem] text-white tracking-wide"
        >
          Architecture
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.25 }}
          className="mt-6 text-jarvis-muted text-[15px] sm:text-base max-w-2xl leading-[1.8]"
        >
          JARVIS uses a distributed edge computing architecture — a Raspberry Pi
          serves as the central brain, coordinating with Arduino boards and a
          Pico for real-time hardware control.
        </motion.p>

        {/* Architecture cards */}
        <div className="mt-14 grid sm:grid-cols-2 gap-4 sm:gap-5">
          {components.map((comp, i) => {
            const styles = accentStyles[comp.accent];
            return (
              <motion.div
                key={comp.name}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.35 + i * 0.12, ease: [0.22, 1, 0.36, 1] }}
                className={`group relative rounded-xl ${styles.border} ${styles.hoverBorder} ${styles.glow} bg-jarvis-card/40 backdrop-blur-sm p-7 sm:p-8 transition-all duration-500 overflow-hidden`}
              >
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-2 h-2 rounded-full ${styles.dot}`} />
                    <span className="text-[9px] tracking-[0.35em] uppercase text-jarvis-muted/70">
                      {comp.role}
                    </span>
                  </div>

                  <h3 className="font-display font-semibold text-lg text-white mb-3">
                    {comp.name}
                  </h3>

                  <p className="text-sm text-jarvis-muted/70 leading-relaxed">
                    {comp.desc}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Flow diagram */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="mt-12 flex flex-wrap items-center justify-center gap-3 sm:gap-4"
        >
          {[
            { text: 'Raspberry Pi', isArrow: false },
            { text: '→', isArrow: true },
            { text: 'Arduino / Pico', isArrow: false },
            { text: '→', isArrow: true },
            { text: 'Motors & Sensors', isArrow: false },
          ].map((item, i) =>
            item.isArrow ? (
              <span key={i} className="text-jarvis-cyan/30 text-base font-light">
                →
              </span>
            ) : (
              <span
                key={i}
                className="px-4 py-2.5 rounded-lg border border-jarvis-border/30 bg-jarvis-card/20 text-jarvis-text/70 text-xs tracking-widest uppercase"
              >
                {item.text}
              </span>
            )
          )}
        </motion.div>
      </div>
    </section>
  );
}
