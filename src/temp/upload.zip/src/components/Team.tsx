import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const team = {
  lead: { name: 'Vikhyat Gupta', role: 'Lead Architect' },
  fabrication: [
    'Aayush Agarwal',
    'Shresth Adukia',
    'Adhyansh Kumar',
    'Rudraksh Sharma',
  ],
  organization: "St. Anthony's School",
};

export default function Team() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section id="team" className="relative py-28 sm:py-40 overflow-hidden">
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] rounded-full bg-jarvis-cyan/[0.015] blur-[200px] pointer-events-none" />

      <div ref={ref} className="max-w-3xl mx-auto px-6 lg:px-10 text-center">
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-[11px] tracking-[0.5em] uppercase text-jarvis-cyan/60 mb-5"
        >
          The Creators
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 35 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.12 }}
          className="font-display font-bold text-2xl sm:text-3xl md:text-[2.75rem] text-white tracking-wide"
        >
          Team
        </motion.h2>

        {/* Lead Architect */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="mt-14 inline-block"
        >
          <div className="rounded-xl border border-jarvis-cyan/15 bg-jarvis-card/30 backdrop-blur-sm px-10 sm:px-14 py-7 sm:py-8">
            <p className="text-[9px] tracking-[0.5em] uppercase text-jarvis-cyan/50 mb-3">
              {team.lead.role}
            </p>
            <p className="font-display font-semibold text-xl sm:text-2xl text-white tracking-wide">
              {team.lead.name}
            </p>
          </div>
        </motion.div>

        {/* Fabrication Team */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="mt-10"
        >
          <p className="text-[9px] tracking-[0.5em] uppercase text-jarvis-muted/50 mb-5">
            Fabrication Team
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            {team.fabrication.map((name, i) => (
              <motion.div
                key={name}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.55 + i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                className="group relative rounded-xl border border-jarvis-border/25 bg-jarvis-card/20 backdrop-blur-sm py-5 px-4 hover:border-jarvis-cyan/15 transition-all duration-500 overflow-hidden"
              >
                {/* Hover glow */}
                <div className="absolute inset-0 rounded-xl bg-jarvis-cyan/[0.015] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                <p className="font-display font-medium text-sm text-white tracking-wide relative z-10">
                  {name}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Organization */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.85 }}
          className="mt-12 flex items-center justify-center gap-4"
        >
          <div className="h-[1px] w-10 bg-gradient-to-r from-transparent to-jarvis-border/40" />
          <p className="text-xs text-jarvis-muted/40 tracking-[0.2em]">
            {team.organization}
          </p>
          <div className="h-[1px] w-10 bg-gradient-to-l from-transparent to-jarvis-border/40" />
        </motion.div>
      </div>
    </section>
  );
}
