import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const highlights = [
  { label: 'Height', value: '4 ft', desc: 'Humanoid scale' },
  { label: 'Brain', value: 'Raspberry Pi', desc: 'Main processing unit' },
  { label: 'Control', value: 'Arduino', desc: 'Hardware interface' },
  { label: 'Type', value: 'Humanoid', desc: 'Bipedal robot' },
];

export default function MeetJarvis() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section id="meet" className="relative py-28 sm:py-40 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-jarvis-purple/[0.02] blur-[200px] pointer-events-none" />

      <div ref={ref} className="max-w-6xl mx-auto px-6 lg:px-10">
        {/* Section header */}
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-[11px] tracking-[0.5em] uppercase text-jarvis-cyan/60 mb-5"
          >
            The Robot
          </motion.p>

          <motion.h2
            initial={{ opacity: 0, y: 35 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.12 }}
            className="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-white tracking-wide"
          >
            Meet JARVIS
          </motion.h2>
        </div>

        {/* Two-column layout: image placeholder + highlights */}
        <div className="grid lg:grid-cols-5 gap-8 items-start">
          {/* Robot image placeholder — takes 3 cols */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="lg:col-span-3"
          >
            <div className="relative aspect-[4/5] sm:aspect-[3/4] rounded-2xl border border-jarvis-border/40 bg-jarvis-card/20 flex items-center justify-center overflow-hidden">
              {/* Corner brackets */}
              <div className="absolute top-3 left-3 w-8 h-8 border-t border-l border-jarvis-cyan/25 rounded-tl-lg" />
              <div className="absolute top-3 right-3 w-8 h-8 border-t border-r border-jarvis-cyan/25 rounded-tr-lg" />
              <div className="absolute bottom-3 left-3 w-8 h-8 border-b border-l border-jarvis-cyan/25 rounded-bl-lg" />
              <div className="absolute bottom-3 right-3 w-8 h-8 border-b border-r border-jarvis-cyan/25 rounded-br-lg" />

              {/* Subtle gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-b from-jarvis-cyan/[0.015] via-transparent to-jarvis-purple/[0.01] pointer-events-none" />

              <div className="text-center px-8">
                <div className="w-14 h-14 mx-auto mb-5 rounded-full border border-jarvis-border/40 flex items-center justify-center">
                  <svg className="w-6 h-6 text-jarvis-muted/30" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <p className="text-jarvis-muted/40 text-xs tracking-widest uppercase">
                  Robot image will be added
                </p>
              </div>
            </div>
          </motion.div>

          {/* Highlight cards — takes 2 cols */}
          <div className="lg:col-span-2 grid grid-cols-2 lg:grid-cols-1 gap-4">
            {highlights.map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 25 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.7, delay: 0.35 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                className="group relative rounded-xl border border-jarvis-border/30 bg-jarvis-card/30 backdrop-blur-sm p-5 sm:p-6 hover:border-jarvis-cyan/20 transition-all duration-500 overflow-hidden"
              >
                {/* Hover glow */}
                <div className="absolute inset-0 rounded-xl bg-jarvis-cyan/[0.02] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                <p className="text-[9px] tracking-[0.35em] uppercase text-jarvis-muted/70 mb-1.5 relative z-10">
                  {item.label}
                </p>
                <p className="font-display font-semibold text-lg text-white relative z-10">
                  {item.value}
                </p>
                <p className="text-[11px] text-jarvis-muted/50 mt-1 relative z-10">
                  {item.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
