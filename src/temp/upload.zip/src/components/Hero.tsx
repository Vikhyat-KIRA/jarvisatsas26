import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

export default function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start start', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.95]);

  return (
    <section
      ref={ref}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Layered background */}
      <div className="absolute inset-0">
        {/* Grid pattern */}
        <div
          className="absolute inset-0 opacity-[0.035]"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0,229,255,0.4) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0,229,255,0.4) 1px, transparent 1px)
            `,
            backgroundSize: '100px 100px',
          }}
        />

        {/* Center radial glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] rounded-full bg-jarvis-cyan/[0.025] blur-[200px] pointer-events-none" />

        {/* Accent glow left */}
        <div className="absolute top-1/4 left-1/5 w-[400px] h-[400px] rounded-full bg-jarvis-purple/[0.03] blur-[150px] pointer-events-none" />

        {/* Accent glow right */}
        <div className="absolute bottom-1/3 right-1/5 w-[350px] h-[350px] rounded-full bg-jarvis-blue/[0.03] blur-[130px] pointer-events-none" />
      </div>

      {/* Animated scan line */}
      <div
        className="absolute left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-jarvis-cyan/15 to-transparent pointer-events-none"
        style={{ animation: 'scan-line 8s linear infinite' }}
      />

      {/* Hero content */}
      <motion.div style={{ y, opacity, scale }} className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="text-[11px] sm:text-xs tracking-[0.5em] uppercase text-jarvis-muted mb-8"
        >
          Meet the star of the show
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.4, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="font-display font-bold text-[4.5rem] sm:text-[7rem] md:text-[9rem] lg:text-[11rem] tracking-[0.12em] text-white leading-[0.85] select-none"
        >
          JARVIS
        </motion.h1>

        {/* Glow accent line */}
        <motion.div
          initial={{ scaleX: 0, opacity: 0 }}
          animate={{ scaleX: 1, opacity: 1 }}
          transition={{ duration: 1.8, delay: 1.1, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto mt-6 h-[1.5px] w-32 sm:w-48 bg-gradient-to-r from-transparent via-jarvis-cyan/80 to-transparent"
        />

        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.4, ease: [0.22, 1, 0.36, 1] }}
          className="mt-8 sm:mt-10 text-sm sm:text-base md:text-lg text-jarvis-muted max-w-md mx-auto leading-relaxed tracking-wide"
        >
          A 4-foot humanoid robot powered by Raspberry Pi and Arduino.
        </motion.p>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.2, duration: 1.2 }}
          className="mt-20 sm:mt-24 flex flex-col items-center gap-3"
        >
          <span className="text-[9px] tracking-[0.4em] uppercase text-jarvis-muted/40">
            Scroll
          </span>
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
            className="w-[1px] h-8 bg-gradient-to-b from-jarvis-cyan/40 to-transparent"
          />
        </motion.div>
      </motion.div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-jarvis-black to-transparent pointer-events-none" />

      {/* Top vignette */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-jarvis-black/50 to-transparent pointer-events-none" />
    </section>
  );
}
