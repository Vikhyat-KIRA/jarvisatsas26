import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const docs = [
  {
    title: 'Build Documentation',
    desc: 'Detailed construction logs and design notes.',
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
    ),
  },
  {
    title: 'Wiring Guides',
    desc: 'Circuit diagrams and connection references.',
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
  },
  {
    title: 'Code Repository',
    desc: 'Source code for control software and firmware.',
    icon: (
      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
      </svg>
    ),
  },
];

export default function Documentation() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section id="docs" className="relative py-28 sm:py-40 overflow-hidden">
      <div className="absolute top-1/2 left-0 w-[400px] h-[400px] rounded-full bg-jarvis-purple/[0.02] blur-[160px] pointer-events-none -translate-y-1/2" />

      <div ref={ref} className="max-w-4xl mx-auto px-6 lg:px-10">
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-[11px] tracking-[0.5em] uppercase text-jarvis-cyan/60 mb-5"
        >
          Resources
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 35 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.12 }}
          className="font-display font-bold text-2xl sm:text-3xl md:text-[2.75rem] text-white tracking-wide mb-14"
        >
          Documentation
        </motion.h2>

        <div className="grid sm:grid-cols-3 gap-4 sm:gap-5">
          {docs.map((doc, i) => (
            <motion.div
              key={doc.title}
              initial={{ opacity: 0, y: 25 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: 0.2 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="group relative rounded-xl border border-jarvis-border/25 bg-jarvis-card/25 backdrop-blur-sm p-7 hover:border-jarvis-cyan/15 transition-all duration-500 overflow-hidden"
            >
              {/* Hover glow */}
              <div className="absolute inset-0 rounded-xl bg-jarvis-cyan/[0.015] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

              <div className="relative z-10">
                <div className="w-10 h-10 rounded-lg border border-jarvis-border/30 bg-jarvis-card/50 flex items-center justify-center mb-5 text-jarvis-muted/40 group-hover:text-jarvis-cyan/40 transition-colors duration-500">
                  {doc.icon}
                </div>

                <h3 className="font-display font-semibold text-[15px] text-white mb-2 tracking-wide">
                  {doc.title}
                </h3>
                <p className="text-sm text-jarvis-muted/60 leading-relaxed mb-5">
                  {doc.desc}
                </p>
                <p className="text-[11px] text-jarvis-muted/30 tracking-wide">
                  Documentation will be added
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
