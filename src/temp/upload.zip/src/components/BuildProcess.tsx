import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const phases = [
  {
    number: '01',
    title: 'Mechanical Construction',
    desc: 'Designing and fabricating the physical frame and structural components of the robot body.',
  },
  {
    number: '02',
    title: 'Electronics Integration',
    desc: 'Wiring the Raspberry Pi, Arduino boards, sensors, and actuators into a unified control system.',
  },
  {
    number: '03',
    title: 'System Assembly',
    desc: 'Bringing together mechanical and electronic subsystems into a complete functional humanoid robot.',
  },
];

export default function BuildProcess() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section id="build" className="relative py-28 sm:py-40 overflow-hidden">
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full bg-jarvis-cyan/[0.02] blur-[180px] pointer-events-none" />

      <div ref={ref} className="max-w-4xl mx-auto px-6 lg:px-10">
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-[11px] tracking-[0.5em] uppercase text-jarvis-cyan/60 mb-5"
        >
          The Process
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 35 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.12 }}
          className="font-display font-bold text-2xl sm:text-3xl md:text-[2.75rem] text-white tracking-wide"
        >
          Build Process
        </motion.h2>

        <div className="mt-14 relative">
          {/* Timeline vertical line */}
          <div className="hidden sm:block absolute left-10 top-0 bottom-0 w-[1px]">
            <motion.div
              initial={{ scaleY: 0 }}
              animate={inView ? { scaleY: 1 } : {}}
              transition={{ duration: 1.5, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="w-full h-full bg-gradient-to-b from-jarvis-cyan/25 via-jarvis-border/30 to-transparent origin-top"
            />
          </div>

          <div className="space-y-6">
            {phases.map((phase, i) => (
              <motion.div
                key={phase.number}
                initial={{ opacity: 0, y: 35 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.25 + i * 0.18, ease: [0.22, 1, 0.36, 1] }}
                className="flex gap-6 sm:gap-8 items-start"
              >
                {/* Number block */}
                <div className="hidden sm:flex flex-shrink-0 w-20 h-20 rounded-xl border border-jarvis-border/40 bg-jarvis-card/30 items-center justify-center">
                  <span className="font-display font-bold text-xl bg-gradient-to-b from-jarvis-cyan to-jarvis-blue bg-clip-text text-transparent">
                    {phase.number}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-1 relative group rounded-xl border border-jarvis-border/25 bg-jarvis-card/25 backdrop-blur-sm p-6 sm:p-7 hover:border-jarvis-cyan/15 transition-all duration-500 overflow-hidden">
                  {/* Hover glow */}
                  <div className="absolute inset-0 rounded-xl bg-jarvis-cyan/[0.015] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                  <span className="sm:hidden font-display text-xs text-jarvis-cyan/50 mb-2 block relative z-10">
                    {phase.number}
                  </span>
                  <h3 className="font-display font-semibold text-lg text-white mb-2.5 tracking-wide relative z-10">
                    {phase.title}
                  </h3>
                  <p className="text-sm text-jarvis-muted/70 leading-relaxed relative z-10">
                    {phase.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
