import { motion } from 'framer-motion';

const footerLinks = [
  { label: 'Vision', id: 'vision' },
  { label: 'Architecture', id: 'architecture' },
  { label: 'Build', id: 'build' },
  { label: 'Team', id: 'team' },
];

export default function Footer() {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="relative border-t border-jarvis-border/15">
      <div className="max-w-6xl mx-auto px-6 lg:px-10 py-14">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-8">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center sm:text-left"
          >
            <p className="font-display font-bold text-base tracking-[0.35em] text-white">
              JARVIS
            </p>
            <p className="text-[10px] text-jarvis-muted/40 mt-1.5 tracking-widest uppercase">
              Humanoid Robotics Project
            </p>
          </motion.div>

          {/* Links */}
          <div className="flex items-center gap-8">
            {footerLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className="text-[10px] tracking-[0.2em] uppercase text-jarvis-muted/40 hover:text-jarvis-cyan/60 transition-colors duration-300"
              >
                {link.label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-jarvis-border/8">
          <p className="text-[10px] tracking-[0.15em] text-jarvis-muted/20 text-center uppercase">
            Project JARVIS · St. Anthony's School
          </p>
        </div>
      </div>
    </footer>
  );
}
