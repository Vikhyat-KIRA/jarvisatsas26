import Navigation from './components/Navigation';
import Hero from './components/Hero';
import Vision from './components/Vision';
import MeetJarvis from './components/MeetJarvis';
import Architecture from './components/Architecture';
import BuildProcess from './components/BuildProcess';
import Documentation from './components/Documentation';
import Team from './components/Team';
import Footer from './components/Footer';

function SectionDivider({ intensity = 'normal' }: { intensity?: 'normal' | 'subtle' }) {
  return (
    <div className="relative">
      <div
        className={`h-[1px] bg-gradient-to-r from-transparent via-jarvis-border/${
          intensity === 'normal' ? '40' : '20'
        } to-transparent`}
      />
    </div>
  );
}

export default function App() {
  return (
    <div className="relative min-h-screen bg-jarvis-black">
      <Navigation />
      <Hero />
      <SectionDivider />
      <Vision />
      <SectionDivider intensity="subtle" />
      <MeetJarvis />
      <SectionDivider />
      <Architecture />
      <SectionDivider intensity="subtle" />
      <BuildProcess />
      <SectionDivider />
      <Documentation />
      <SectionDivider intensity="subtle" />
      <Team />
      <Footer />
    </div>
  );
}
